#include "process_log.h"

// Static library definitions
// 
int get_proc_log_level() {
    int result = syscall(PROC_LOG_GET);
    if (result < 0) return -1;
    return result;
}

int set_proc_log_level(int new_level) {
    int result = syscall(PROC_LOG_SET, new_level);
    if (result < 0) return -1;
    return result;
}

int proc_log_message(int level, char* message) {
    int result = syscall(PROC_LOG_CALL, message, level);
    if (result < 0) return -1;
    return result;
}

// Harness functions
///////////////////////////////////////////////////////////////

int* retrieve_set_level_params(int new_level) {
    int* result = (int*)malloc(3 * sizeof(int));
    result[0] = PROC_LOG_SET;
    result[1] = 1;
    result[2] = new_level;

    return result;
}

int* retrieve_get_level_params() {
    int* result = (int*)malloc(2 * sizeof(int));
    result[0] = PROC_LOG_GET;
    result[1] = 0;

    return result;
}

int interpret_set_level_result(int ret_value) {
    if (ret_value < 0) return -1;
    return ret_value;
}

int interpret_get_level_result(int ret_value) {
    if (ret_value < 0) return -1;
    return ret_value;
}

int interpret_log_message_result(int ret_value) {
    if (ret_value < 0) return -1;
    return ret_value;
}
