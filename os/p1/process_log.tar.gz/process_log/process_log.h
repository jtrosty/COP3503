#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

#define PROC_LOG_GET 335
#define PROC_LOG_SET 336
#define PROC_LOG_CALL 337

// Static Library
////////////////////////////////////////////////////////////
// Gets the process log level from the kernel.
// On success, return process log level, on failure, returns -1
int get_proc_log_level();

// REQUIRES ROOT PERMISSION
// Sets the process log level in kernel.
// On success, returns new log level, on failure, returns -1
int set_proc_log_level(int new_level);

// If level input is correct, between 0 and 7, will log message into
// kernel logging system.  On success, returns process_log_level
// On failure returns -1.
int proc_log_message(int level, char* message);

// Harness functions
// /////////////////////////////////////////////////////////////

int* retrieve_set_level_params(int new_level);

int* retrieve_get_level_params();

int interpret_set_level_result(int ret_value);

int interpret_get_level_result(int ret_value);

int interpret_log_message_result(int ret_value);
